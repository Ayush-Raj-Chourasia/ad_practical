# ad_practical
